// ============================================================
// env.js — Runtime credentials loader
// Keys are XOR-obfuscated. Never store plain credentials here.
// ============================================================
(function (G) {
  'use strict';

  const _a = 'DDwDRD8IX2IfIl0XIBo6HFQgHi0RLV0KPhMgEnsaRDEOJwxFL0UgAQ==';
  const _b = 'ATE9XC51EyQ5J3M4BwkCQXk9MSQzLGFWJSQQUxwCQRk5BicPZA46JCALAykhOF0GSBQVNCZgHBQJESN+JzE5MC5pCg9REAg5GmsGNTwMbgwYGl0CBVUJPAFWIV5EKT4iCjg7BCITWm0LDSkLBSorISwHZ11YDSwPHW8SOiohOi0DKjIUBgJYMXw7JGACGx4dRFQXMWE3KHJWCx0QHxsDZDghK10YLzMMOmc6QwAuDVx4dDoMOwZ+HAUbI0RtLjNgKwlbDCdKHhUTK2I2Lnc+Yw==';
  const _k = [100,72,119,52,76,50,112,77,118,78,57,113,82,115,75,112,55,84,120,87,122,66,51,99,70,103,89,101,85,105,49,65,111,69,109,54,74,107,67,110,80,104,48];

  function _x(b64) {
    const raw = atob(b64);
    let out = '';
    for (let i = 0; i < raw.length; i++) {
      out += String.fromCharCode(raw.charCodeAt(i) ^ _k[i % _k.length]);
    }
    return out;
  }

  // تُكشف مرة واحدة في runtime، لا تُخزّن في متغير عام
  Object.defineProperty(G, '__DW_ENV', {
    get: function () {
      return { u: _x(_a), k: _x(_b) };
    },
    configurable: false,
    enumerable: false,
  });

})(window);
